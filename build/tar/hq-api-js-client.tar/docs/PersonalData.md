# @FlocktoryHqApi.PersonalData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstName** | **String** |  | [optional] 
**secondName** | **String** |  | [optional] 
**surname** | **String** |  | [optional] 


