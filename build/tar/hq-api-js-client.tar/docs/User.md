# @FlocktoryHqApi.User

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**login** | **String** |  | [optional] 
**personalData** | [**PersonalData**](PersonalData.md) |  | [optional] 
**contactInformation** | [**ContactInformation**](ContactInformation.md) |  | [optional] 


