# @FlocktoryHqApi.UserApi

All URIs are relative to *https://hq.api.floctory.ru*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createUser**](UserApi.md#createUser) | **POST** /user | Create user



## createUser

> createUser(user)

Create user

This can only be done by the logged in user.

### Example

```javascript
import @FlocktoryHqApi from '@flocktory/hq-api';

let apiInstance = new @FlocktoryHqApi.UserApi();
let user = new @FlocktoryHqApi.User(); // User | Created user object
apiInstance.createUser(user, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user** | [**User**](User.md)| Created user object | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: Not defined

