# @FlocktoryHqApi.ContactInformation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** |  | [optional] 
**phone** | **String** |  | [optional] 


